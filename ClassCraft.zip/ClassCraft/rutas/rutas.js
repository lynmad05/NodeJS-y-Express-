var express = require('express');  
var router = express.Router();  
var falumnos= require('./rutas_alumnos.js');
var fcursos = require('./rutas_cursos.js');
var fprofesores = require('./rutas_profesores.js');

// Pagina Principal  
router.get('/', c_inicio);  

// Opciones principales  
router.get('/mantenimientos', c_mantenimientos);  
 

//opciones de mantenimineto de Alumnos
router.get('/m_alumnos_listado', falumnos.listado);
router.get('/m_alumnos_nuevo', falumnos.nuevo);
router.post('/m_alumnos_grabar_nuevo', falumnos.grabar_nuevo);
router.get('/m_alumnos_editar/:xid', falumnos.editar);
router.post('/m_alumnos_grabar_editar', falumnos.grabar_editar);
router.get('/m_alumnos_eliminar/:xid', falumnos.eliminar);


//De Cursos
router.get('/m_cursos_listado', fcursos.listado);
router.get('/m_cursos_nuevo', fcursos.nuevo);
router.post('/m_cursos_grabar_nuevo', fcursos.grabar_nuevo);
router.get('/m_cursos_editar/:xid', fcursos.editar);
router.post('/m_cursos_grabar_editar', fcursos.grabar_editar);
router.get('/m_cursos_eliminar/:xid', fcursos.eliminar);


//De Profesores
router.get('/m_profesores_listado', fprofesores.listado);
router.get('/m_profesores_nuevo', fprofesores.nuevo);
router.post('/m_profesores_grabar_nuevo', fprofesores.grabar_nuevo);
router.get('/m_profesores_editar/:xid', fprofesores.editar);
router.post('/m_profesores_grabar_editar', fprofesores.grabar_editar);
router.get('/m_profesores_eliminar/:xid', fprofesores.eliminar);

function c_inicio(req, res) {  
    res.render('index',{});  
}  

function c_mantenimientos(req, res) {  
    res.render('mantenimientos', {});  
}  


module.exports = router;