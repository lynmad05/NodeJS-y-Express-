var mongojs = require('mongojs')  
var uri = 'mongodb://localhost:27017/ClassCraft';  
var db = mongojs(uri, ['Alumnos']);  

function alumnos_listado(req, res) {  
    db.Alumnos.find().sort({nombre:1}, function (err, records) {  
        if (err) {  
            console.log('Error al acceder a la base de datos.');  
            return;  
        }  
        res.render('m_alumnos_listado', {records: records});  
    });  
}  

module.exports = {  
    listado: function (req, res) {  
        alumnos_listado(req, res);  
    },
    nuevo: function(re, res){
        res.render('m_alumnos_nuevo',{});
    },

    grabar_nuevo: function (req, res) {
        var xnom = req.body['xnom'];
        var xedad = req.body['xedad'];
        var xemail= req.body['xemail'];
    
        db.Alumnos.find().sort({_id:-1}, function (err, records) {
            if (err) {
                console.log('Error al acceder a la base de datos.');
                res.end();
                return;
            }
            var xid = records[0]?._id + 1 || 1;  
            db.Alumnos.insert({_id: xid, nombre: xnom, edad: xedad, email: xemail}, function () {
                alumnos_listado(req, res);  
            });
        });
    },
    

    editar: function (req, res) {  
        var xid = req.params.xid*1;  
        console.log(xid);  
        db.Alumnos.find({_id: xid}, function (err, records) {  
            if (err) {  
                console.log('Error al acceder a la base de datos.'); 
                res.end(); 
                return;  
            }  
            res.render('m_alumnos_editar', {alumnos: records[0]});  
        });  
    },

    grabar_editar: function (req, res) {  
        var xid = req.body['xid'] * 1;  
        var xnom = req.body['xnom'];  
        var xedad = req.body['xedad'];
        var xemail= req.body['xemail'];
        db.Alumnos.update({_id: xid}, { $set: { nombre: xnom, edad: xedad, email: xemail } }, function () {
  
            alumnos_listado(req, res);  
        });  
    },

    eliminar: function(req, res) {
        var xid = req.params.xid * 1;
        db.Alumnos.remove({_id: xid}, function() {
            alumnos_listado(req, res);
        });
    }
    

}
