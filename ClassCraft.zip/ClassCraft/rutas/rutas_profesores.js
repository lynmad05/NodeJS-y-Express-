var mongojs = require('mongojs')  
var uri = 'mongodb://localhost:27017/ClassCraft';  
var db = mongojs(uri, ['Profesores']);  

function profesores_listado(req, res) {  
    db.Profesores.find().sort({nombre:1}, function (err, records) {  
        if (err) {  
            console.log('Error al acceder a la base de datos.');  
            return;  
        }  
        res.render('m_profesores_listado', {records: records});  
    });  
}  

module.exports = {  
    listado: function (req, res) {  
        profesores_listado(req, res);  
    },
    nuevo: function(req, res){
        res.render('m_profesores_nuevo',{});
    },

    grabar_nuevo: function (req, res) {
        var xnom = req.body['xnom'];
        var xesp = req.body['xesp'];
       
    
        db.Profesores.find().sort({_id:-1}, function (err, records) {
            if (err) {
                console.log('Error al acceder a la base de datos.');
                res.end();
                return;
            }
            var xid = records[0]?._id + 1 || 1;  
            db.Profesores.insert({_id: xid, nombre: xnom, especialidad:xesp}, function () {
                profesores_listado(req, res);  
            });
        });
    },
    

    editar: function (req, res) {  
        var xid = req.params.xid*1;  
        console.log(xid);  
        db.Profesores.find({_id: xid}, function (err, records) {  
            if (err) {  
                console.log('Error al acceder a la base de datos.'); 
                res.end(); 
                return;  
            }  
            res.render('m_profesores_editar', {profesores: records[0]});  
        });  
    },

    grabar_editar: function (req, res) {  
        var xid = req.body['xid'] * 1;  
        var xnom = req.body['xnom'];
        var xesp = req.body['xesp'];  
        
        db.Profesores.update({_id: xid}, { $set: { nombre: xnom, especialidad:xesp} }, function () {
  
            profesores_listado(req, res);  
        });  
    },

    eliminar: function(req, res) {
        var xid = req.params.xid * 1;
        db.Profesores.remove({_id: xid}, function() {
            profesores_listado(req, res);
        });
    }
    

}
