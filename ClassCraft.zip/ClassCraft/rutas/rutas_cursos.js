var mongojs = require('mongojs')  
var uri = 'mongodb://localhost:27017/ClassCraft';  
var db = mongojs(uri, ['Cursos']);  

function cursos_listado(req, res) {  
    db.Cursos.find().sort({nombre:1}, function (err, records) {  
        if (err) {  
            console.log('Error al acceder a la base de datos.');  
            return;  
        }  
        res.render('m_cursos_listado', {records: records});  
    });  
}  

module.exports = {  
    listado: function (req, res) {  
        cursos_listado(req, res);  
    },
    nuevo: function(re, res){
        res.render('m_cursos_nuevo',{});
    },

    grabar_nuevo: function (req, res) {
        var xnom = req.body['xnom'];
        var xcod = req.body['xcod'];
        var xcred= req.body['xcred'];
    
        db.Cursos.find().sort({_id:-1}, function (err, records) {
            if (err) {
                console.log('Error al acceder a la base de datos.');
                res.end();
                return;
            }
            var xid = records[0]?._id + 1 || 1;  
            db.Cursos.insert({_id: xid, nombre: xnom, codigo: xcod, creditos: xcred}, function () {
                cursos_listado(req, res);  
            });
        });
    },
    

    editar: function (req, res) {  
        var xid = req.params.xid*1;  
        console.log(xid);  
        db.Cursos.find({_id: xid}, function (err, records) {  
            if (err) {  
                console.log('Error al acceder a la base de datos.'); 
                res.end(); 
                return;  
            }  
            res.render('m_cursos_editar', {cursos: records[0]});  
        });  
    },

    grabar_editar: function (req, res) {  
        var xid = req.body['xid'] * 1;  
        var xnom = req.body['xnom'];  
        var xcod = req.body['xcod'];
        var xcred= req.body['xcred'];
    
        db.Cursos.update({_id: xid}, { $set: { nombre: xnom, codigo: xcod, creditos: xcred } }, function () {
  
            cursos_listado(req, res);  
        });  
    },

    eliminar: function(req, res) {
        var xid = req.params.xid * 1;
        db.Cursos.remove({_id: xid}, function() {
            cursos_listado(req, res);
        });
    }
    

}
