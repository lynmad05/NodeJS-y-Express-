var mongojs = require('mongojs');  
var uri = 'mongodb://localhost:27017/Lab02';  
var db = mongojs(uri, ['Areas']);  

function areas_listado(req, res) {  
    db.Areas.find().sort({nombre:1}, function (err, records) {  
        if (err) {  
            console.log('Error al acceder a la base de datos.');  
            return;  
        }  
        res.render('m_areas_listado', {records: records});  
    });  
}

module.exports = {  
    listado: function (req, res) {  
        areas_listado(req, res);  
    },

    nuevo: function(req, res) {
        res.render('m_areas_nuevo', {});
    },

    grabar_nuevo: function (req, res) {
        var xnom = req.body['xnom'];
        var xsue = req.body['xsue'];
    
        db.Areas.find().sort({_id:-1}, function (err, records) {
            if (err) {
                console.log('Error al acceder a la base de datos.');
                res.end();
                return;
            }
            var xid = records[0]?._id + 1 || 1;  
            db.Areas.insert({_id: xid, nombre: xnom, sueldo: xsue}, function () {
                areas_listado(req, res);  
            });
        });
    },
    

    editar: function (req, res) {  
        var xid = req.params.xid*1;  
        db.Areas.find({_id: xid}, function (err, records) {  
            if (err) {  
                console.log('Error al acceder a la base de datos.'); 
                res.end(); 
                return;  
            }  
            res.render('m_areas_editar', {area: records[0]});  
        });  
    },

    grabar_editar: function (req, res) {  
        var xid = req.body['xid'] * 1;  
        var xnom = req.body['xnom'];  
        var xsue = req.body['xsue'];  
        db.Areas.update({_id: xid}, { $set: { nombre: xnom, sueldo: xsue } }, function () {
            areas_listado(req, res);  
        });  
    },

    eliminar: function(req, res) {
        var xid = req.params.xid * 1;  
        db.Areas.remove({_id: xid}, function() {
            areas_listado(req, res);  
        });
    }
}
